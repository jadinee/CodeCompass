import os
from typing import Optional
from rocketride import RocketRideClient

# Pipeline client and token are cached globally
_client: Optional[RocketRideClient] = None
_token: Optional[str] = None


async def get_client_and_token() -> tuple[RocketRideClient, str]:
    """Get or create the RocketRide client and pipeline token."""
    global _client, _token

    if _client is None or _token is None:
        _client = RocketRideClient()  # reads ROCKETRIDE_URI and ROCKETRIDE_APIKEY from .env
        await _client.connect()
        result = await _client.use(filepath='codecompass.pipe')
        _token = result['token']
        print(f"[RocketRide] Pipeline started with token: {_token}")

    return _client, _token


async def call_pipeline(project_context: str, conversation_history: list = None) -> Optional[str]:
    """Send project context to RocketRide pipeline and return the response."""
    try:
        client, token = await get_client_and_token()
        response = await client.send(token, project_context)
        return extract_answer(response)
    except Exception as e:
        raise RuntimeError(f"Pipeline error: {e}")


async def call_followup(question: str, project_context: str, previous_analysis: str) -> Optional[str]:
    """Send a follow-up question with full context."""
    try:
        client, token = await get_client_and_token()
        combined = (
            f"Previous project analysis:\n{previous_analysis[:2000]}\n\n"
            f"User follow-up question: {question}"
        )
        response = await client.send(token, combined)
        return extract_answer(response)
    except Exception as e:
        raise RuntimeError(f"Follow-up error: {e}")


def extract_answer(data: dict) -> str:
    """Extract the answer text from RocketRide's response."""
    if not data:
        return "No response received from pipeline."

    if "answers" in data:
        answers = data["answers"]
        if isinstance(answers, list) and answers:
            item = answers[0]
            if isinstance(item, dict):
                return item.get("text", str(item))
            return str(item)
        return str(answers)

    for key in ("result", "output", "text", "message"):
        if key in data:
            return str(data[key])

    return str(data)
